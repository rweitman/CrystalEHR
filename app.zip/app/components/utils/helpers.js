var axios = require("axios");

var Helper = {

  loginAuth: function (request) {
    console.log("Log Helpers: " + request);
    return axios.post("/login", request).then((res) => {
      // console.log(response);

    });
  },

  signUp: function (request) {
      return axios.post("/signup", request).then((res) => {

      });
  }


}; // END HELPER CLASS

module.exports = Helper;
